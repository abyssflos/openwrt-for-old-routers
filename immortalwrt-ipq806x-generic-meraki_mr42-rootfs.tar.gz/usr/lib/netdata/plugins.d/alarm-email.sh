#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-or-later

# OBSOLETE - REPLACED WITH
# alarm-notify.sh

${0/alarm-email.sh/alarm-notify.sh} "${@}"
