alias btop="btop --force-utf"
